﻿using System;
using LibUdp.BASIC.SEND;
using LibUdp.BASIC.RECEIVE;
using TimerMockable;

namespace HomeAutomationLibs
{
 
}
