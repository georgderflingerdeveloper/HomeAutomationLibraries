﻿namespace SystemServices
{
    public interface ITimeUtil
    {
        string IGetTimeStamp();
    }
}
