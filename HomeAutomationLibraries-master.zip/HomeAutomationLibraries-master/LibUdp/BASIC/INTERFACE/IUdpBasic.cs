﻿using System;

namespace LibUdp.BASIC.INTERFACE
 {
    public interface IUdpBasic
    {
 
    }
}
