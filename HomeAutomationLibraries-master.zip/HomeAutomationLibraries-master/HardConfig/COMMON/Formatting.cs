﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace HardConfig.COMMON
{
    static class FormatConstants
    {
        public const string TransactionNumberFormat = "{0:000000000}";
        public const string TransactionNumberFormat_ = "000000000";
    }
}
